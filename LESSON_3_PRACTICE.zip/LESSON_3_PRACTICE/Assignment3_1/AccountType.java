package Assignment3_1;

public enum AccountType {
    CHECKING,
    SAVINGS,
    RETIREMENT;
}
