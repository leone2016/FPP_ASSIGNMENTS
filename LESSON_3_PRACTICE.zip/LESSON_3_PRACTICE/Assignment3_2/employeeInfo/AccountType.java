package Assignment3_2.employeeInfo;

public enum AccountType {
    CHECKING,
    SAVINGS,
    RETIREMENT;
}
