package ASSIGNMENT4_4.good;

public interface Polygon {
     int getNumberOfSides();
     double computePerimeter();
}
