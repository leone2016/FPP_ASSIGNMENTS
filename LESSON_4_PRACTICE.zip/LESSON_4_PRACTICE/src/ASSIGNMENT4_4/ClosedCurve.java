package ASSIGNMENT4_4;

public abstract class ClosedCurve {
      abstract double computeArea();
}
