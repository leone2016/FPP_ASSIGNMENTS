package ASSIGNMENT4_3.employeeInfo;

public enum AccountType {
    CHECKING,
    SAVINGS,
    RETIREMENT;
}
