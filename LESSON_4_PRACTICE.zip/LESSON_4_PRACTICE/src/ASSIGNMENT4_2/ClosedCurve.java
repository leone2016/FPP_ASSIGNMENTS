package ASSIGNMENT4_2;

abstract public class ClosedCurve {
      protected abstract double computeArea();
}
